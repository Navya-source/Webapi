using System;
using System.Linq;
using WebApplication.Controllers;
using Xunit;

namespace XUnitTest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            var controller = new ValuesController();
            var result = controller.Get();
            Assert.Equal(2, result.Count());

        }
    }
}
